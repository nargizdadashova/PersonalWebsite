# Mywebsite
This project is a personal website. The site aims to present information about myself, my interests, and hobbies, and it is being developed using web technologies such as HTML, CSS, and, in the future, JavaScript and PHP.
